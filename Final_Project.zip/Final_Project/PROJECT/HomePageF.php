<?php
require_once 'HomeHeader.php';
?>


<html>
	<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" type="text/css" href="CSS/Style.css">
	</head>
	<body>
		<div id="slider">
			<figure>
				<img src="images/hotelNew2.jpg" width="1365px" height="540px" >
				<img src="images/hotelNew5.jpg" width="1365px" height="540px" >
				<img src="images/hotelImage2.jpg" width="1365px" height="540px">
				<img src="images/hotelNew6.jpg" width="1365px" height="540px">
				<img src="images/hotelNew1.jpg" width="1365px" height="540px">
			<figure>	
		</div>
		<br>
		<br>
	<table>
		<tr>
			<td colspan="5" align="center">
				<h3 style="color:Orange"><u><i>Others</i></u></h3>
			</td>
		</tr>
		<tr>
			<td>
				<br>
			</td>
		</tr>
		<tr>
			<td align="center">
				<img width="600px" height="500px" src="images/4 beds.jpg">
			</td>
			<td colspan="2">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</td>
			<td colspan="2" align="center">
				<h3><i>Luxurious Hotel</i></h3>
				<hr><br>
				<p> we are dedicated in making sure that your visit to Dhaka is memorable, comfortable and delightful.</p>
			</td>
		</tr>
	</table>
	</div>
	<!--<br>	
	<br>
	<div>
		<h3 align="center" style="color:Orange"><u><i>About Us</i></u></h3>
		<div style="font-size: 150%" margin="25%">
                 A global, multicultural, privately-owned company, founded in Dhaka, Bangladesh.
                  Still run every day by the four co-founders,
                  <b>Zubair Ahmed</b>  
                , <b> Kaniz Fatema Kanta </b>,
                <b> Sheikh Mahmudul Hasan Shium </b>, and,  
                <b>   Shafiur Rahman</b>.
                  XYABC hotelsoftware has been developing and selling technology and service solutions specifically for the hotel industry and
                   related sectors for more than 25 years. The consistent focus on the demands of a single industry makes protel one of the most 
                   experienced and successful providers of hospitality technology. In fact, we are a worldwide leader in hotel technology solutions.
            </div>
	</div>-->
	</body>
	<?php require_once 'CommonFooter.php';?>
</html>