<html>
<head>
</head>
<body>
    
	<table align="center" style="background-color:rgb(240, 240, 240); width:100%; height:5%;">
		<tr>
			<td colspan="4" align="center">
				<h1 style="color:Orange"><i>Gallery</i></h1>
				<hr>
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="images/4 beds.jpg">
			</td>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="images/2 beds.jpg">
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="images/Resturant pic.jpg">
			</td>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="images/Room.jpg">
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="images/Spa.jpg">
			</td>
			<td colspan="2" align="center">
				<img width="600px" height="500px" src="images/gym.jpg">
			</td>
		</tr>
	</table>
</body>
</html>