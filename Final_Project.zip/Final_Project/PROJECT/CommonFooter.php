<br>
<br>
<br>
<table align="center" style="background-color:rgb(0, 40, 40); width:100%; height:5%;">
		<tr>
			<td>
				<br>
				<br>
				<p  style="font-size: 150%; color:white"><b><i>*HOTEL BLUE OCEAN*</i></b></p>
				<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="About.php" style="color:white"><i>About Us</i>
			</td>
			<td align="center">
				<br>
				<p style="color:white"><i>Contuct Us</i><br>
				<br>019xxxxxxxx&nbsp;,&nbsp;018yyyyyyyy<br>
				<br>Email: blueocean@gmail.com</p>
			</td>
		</tr>
		<tr>
			<td align="center">
				
			</td>
			<td colspan="2" align="center">
				<p  style="font-size: 110%; color:white"><b><i>---Thank You---</i></b></p>
			</td>
			<td>
			</td>
		</tr>
		<tr>
			<td>
			</td>
			<td>
			</td>
		</tr>		
</table>