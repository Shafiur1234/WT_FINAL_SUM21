<html>
    <body>
        <fieldset style="border-color:blue">
            <h1 style="color:Green">Company Profile</h1>
            <div>
                 A global, multicultural, privately-owned company, founded in Dhaka, Bangladesh.
                  Still run every day by the four co-founders,
                  <b>Zubair Ahmed</b>  
                , <b> Kaniz Fatema Kanta </b>,
                <b> Sheikh Mahmudul Hasan Shium </b>, and,  
                <b>   Shafiur Rahman</b>.
                  XYABC hotelsoftware has been developing and selling technology and service solutions specifically for the hotel industry and
                   related sectors for more than 25 years. The consistent focus on the demands of a single industry makes protel one of the most 
                   experienced and successful providers of hospitality technology. In fact, we are a worldwide leader in hotel technology solutions.
            </div>
        </fieldset>
    </body>

</html>