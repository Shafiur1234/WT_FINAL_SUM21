<html>
<body>
<fieldset style="border-color: blue">
<table align="left">
<tr><td><a href="HomePageF.php"><input type="submit" value="Home"> </a></td>

</table>
<table align="right">

<td><a href="Login.php"><input type="submit" value="Logout"> </a></td></tr>
</table>
</fieldset>
</body>
</html>
