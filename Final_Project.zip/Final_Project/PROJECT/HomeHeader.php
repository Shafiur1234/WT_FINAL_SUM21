<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
    
	<table align="center" style="background-color:rgb(240, 240, 240); width:100%; height:5%;">
		<tr>
			<td>
				<p>&nbsp;&nbsp;&nbsp;&nbsp;Hotline Number:&nbsp;+88019xxxxxxxx,&nbsp;+88018yyyyyyyy</p>
			</td>
			<td>
				<p  style="font-size: 150%;"><b><i>*HOTEL BLUE OCEAN*</i></b></p>
			</td>
			<td align="right">
				&nbsp;&nbsp;&nbsp;&nbsp;<a href="SignUp.php" class="btn btn-info">Sign Up</a>
			</td>
			<td align="right">
				<a href="Login.php" class="btn btn-danger">Book Now</a>
			</td>
		</tr>
		<tr>
			<td colspan="4">
			</td>
			<td colspan="3">
			</td>
		</tr>
		<tr>
			<td colspan="4">
			</td>
			<td colspan="3">
			</td>
		</tr>
		
	</table>
	<table align="center" style="background-color:rgb(220, 220, 220); width:100%; height:7%;">
		<tr>
			<td colspan="2" align="center">
				<a href="HomePageF.php"><b>Home</b></a>
			</td>
			<td colspan="2" align="center">
				<a href="AllRooms.php"><b>Rooms</b></a>
			</td>
			<td colspan="2" align="center">
				<a href="Login.php"><b>Reservation</b></a>
			</td>
			<td colspan="2" align="center">
				<a href="Gallery.php"><b>Gallery</b></a>
			</td>
			<td colspan="2" align="center">
				<a href="Events.php"><b>Events</b></a>
			</td>
			<td colspan="2" align="center">
				<a href="GymReserve.php"><b>Gym</b></a>
			</td>
			<td colspan="2" align="right">
				<a href="Spa.php"><b>Spa</b></a>
			</td>
			<td colspan="2" align="right">
				<a href="Restaurant.php"><b>Resturant</b></a>
			</td>
			<td  align="center">
				<a href="Special_offer.html"><b>Special Offers</b></a>
			</td>
			<td  align="center">
				<a href="AllNotices.php"><b>Notices</b></a>
			</td>
			<td  align="center">
				<a href="AllReviews.php"><b>Reviews</b></a>
			</td>
		</tr>
	</table>